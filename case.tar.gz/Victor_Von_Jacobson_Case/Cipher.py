## File for decrypting messages
## In GitHub Codespaces the cryptography library is already installed.
## Running on your own computer? Install it first: pip install cryptography

from cryptography.fernet import Fernet, InvalidToken

# Step 1: Find the key (it's hidden somewhere near the victim...)
# Replace None with the key, exactly as you found it, including the b'...'
key = None

# Step 2: Paste the encrypted message you found between the quotes
message = ""

#Fernet is a symmetric (secret-key) authenticated cryptography specification and implementation
# that makes sure a message cannot be read or changed without the right key
if key is None or message == "":
    print("Fill in the key and the message first, then run this file again!")
else:
    f = Fernet(key)
    try:
        print(f.decrypt(message).decode())
    except InvalidToken:
        print("That didn't decrypt. Make sure you copied the whole message and the right key.")
