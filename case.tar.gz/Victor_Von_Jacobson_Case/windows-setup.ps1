# Windows doesn't treat names starting with "." as hidden, so this marks them hidden.
# After running it, ls won't show them but ls -Force will, just like ls -a on Mac/Linux.
Get-ChildItem -Path $PSScriptRoot -Recurse -Force |
    Where-Object { $_.Name.StartsWith(".") } |
    ForEach-Object { $_.Attributes = $_.Attributes -bor [System.IO.FileAttributes]::Hidden }
Write-Host "Done! Hidden rooms are hidden. Use ls -Force to find them."
